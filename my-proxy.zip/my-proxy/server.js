const express = require('express');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;

// 静的ファイルの提供（publicフォルダの中身を自動で配信）
app.use(express.static(path.join(__dirname, 'public')));

// ★ ① トップページ（` / `）にアクセスが来たときの処理を明示する
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ② プロキシ中継用エンドポイント（パス形式 /service/エンコードURL & Google翻訳対策付き）
app.get('/service/:encodedUrl', async (req, res) => {
    let targetUrl;
    try {
        targetUrl = decodeURIComponent(req.params.encodedUrl);
    } catch (e) {
        return res.status(400).send('URLのデコードに失敗しました');
    }

    if (!targetUrl) {
        return res.status(400).send('URLが指定されていません');
    }

    try {
        const response = await fetch(targetUrl, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            }
        });

        const contentType = response.headers.get('content-type') || 'text/html';
        const buffer = await response.arrayBuffer();

        // ★ Google翻訳や外部フレームからの読み込み・制限を回避する重要設定
        res.removeHeader('X-Frame-Options');
        res.removeHeader('Content-Security-Policy');
        res.setHeader('Access-Control-Allow-Origin', '*');

        // もしHTMLレスポンスだったら、中のDuckDuckGoリンクを /service/ 用に書き換える
        if (contentType.includes('text/html')) {
            let html = Buffer.from(buffer).toString('utf-8');

            // DuckDuckGoのトラッキング/転送リンクを自動的に /service/ に書き換える
            html = html.replace(/href="(?:https:\/\/duckduckgo\.com)?\/l\/\?uddg=([^"&]+)[^"]*"/g, (match, uddg) => {
                return `href="/service/${uddg}"`;
            });

            res.setHeader('Content-Type', 'text/html; charset=utf-8');
            return res.send(html);
        }

        // 画像やCSSなどのその他のファイルはそのまま返す
        res.setHeader('Content-Type', contentType);
        res.send(Buffer.from(buffer));

    } catch (err) {
        res.status(500).send(`[r0xy proxy Error] プロキシ通信に失敗しました: ${err.message}`);
    }
});

app.listen(PORT, () => {
    console.log(`[r0xy proxy] Server running on http://localhost:${PORT}`);
});