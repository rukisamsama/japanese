// r0xy proxy - Service Worker (Bare Server 経由)
const BARE_URL = 'https://bare-er3w.onrender.com/';

self.addEventListener('install', (event) => {
    self.skipWaiting();
});

self.addEventListener('activate', (event) => {
    event.waitUntil(self.clients.claim());
});

self.addEventListener('fetch', (event) => {
    const url = new URL(event.request.url);

    // /service/ で始まるパスへのアクセスをキャッチ
    if (url.pathname.startsWith('/service/')) {
        event.respondWith(
            (async () => {
                try {
                    // エンコードされたターゲットURLを取り出す
                    const encodedTarget = url.pathname.substring(9);
                    if (!encodedTarget) {
                        return new Response('URLが指定されていません', { status: 400 });
                    }
                    const targetUrl = decodeURIComponent(encodedTarget);

                    // Render上の Bare Server に合わせたリクエスト形式で転送
                    // Bare Server は通常、ヘッダーにターゲットURLを指定するか、エンドポイント経由で通信します
                    const bareRequestUrl = new URL(targetUrl, BARE_URL).toString();

                    // Bare Server を通して外部へリクエストを送信
                    const response = await fetch(targetUrl, {
                        method: event.request.method,
                        headers: {
                            ...event.request.headers,
                            // 必要に応じてBare用のカスタムヘッダーを追加
                            'x-bare-url': targetUrl
                        },
                        redirect: 'follow'
                    });

                    return response;
                } catch (err) {
                    return new Response(`[r0xy proxy Error] Bare通信に失敗しました: ${err.message}`, {
                        status: 500,
                        headers: { 'Content-Type': 'text/plain; charset=utf-8' }
                    });
                }
            })()
        );
    }
});